import '@babel/polyfill'
import Vue from 'vue'
import './plugins/axios'
import BootstrapVue from 'bootstrap-vue'
import datePicker from 'vue-bootstrap-datetimepicker'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'pc-bootstrap4-datetimepicker/build/css/bootstrap-datetimepicker.css'
import App from './App.vue'
import router from './router'
import store from './store'
import 'vue-awesome/icons'
import Icon from 'vue-awesome/components/Icon'
import VueBootstrapTypehead from 'vue-bootstrap-typeahead'
import moment from 'moment'
import VueMomentLib from 'vue-moment-lib'
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.min.css'

Vue.component('v-icon', Icon)
Vue.component('vue-bootstrap-typehead', VueBootstrapTypehead)
Vue.component('multiselect', Multiselect)

moment.locale('ru')

Vue.use(VueMomentLib, {moment: moment})
Vue.use(BootstrapVue)
Vue.use(datePicker)

Vue.config.productionTip = false

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')
