<template>
    <fieldset>
        <button type="button" @click="addNewBaseRequest()" class="btn btn-success mr-2">
            <v-icon name="check"/> Отправить
        </button>
        <button type="button" class="btn btn-primary mr-2">
            <v-icon name="save"/> Сохранить
        </button>
        <button type="button" class="btn btn-danger mr-2">
            <v-icon name="ban"/> Отмена
        </button>
    </fieldset>
</template>

<script>

/** Импорт констант */
import {
    REGISTRY_REQUEST_FOR_CUSTOMER,
    REGISTRY_SAMPLES,
    REGISTRY_REQUEST_FOR_RESEARCHER,
    REGISTRY_REQUEST_FOR_TESTER
} from '../../../constants/constants'

export default {
    methods: {
        /**
         * Запрос на добавлени в список «Реестр заявок» для заявителя и регистратора
         * Пока не определился с ответом
         */
        addNewBaseRequest() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Добавление Вашей заявки...' })
            console.log('Начинаем добавлять основную заявку...')
            // добавляем основную заявку
            const payload = {
                listId: REGISTRY_REQUEST_FOR_CUSTOMER,
                jsonBody: this.$store.state.a.dataFromBaseForm, // данные из хранилища "a-store"
            }
            this.$store.dispatch('createItem', payload)
            // сохраняем образцы
            .then( response => {
                let samples = this.$store.state.a.dataSamples
                if (Object.keys(samples).length != 0) {
                    console.log('Начинаем добавлять образцы...')
                    samples.forEach(element => {
                        let data = {
                                __metadata: {type: 'SP.ListItem'},
                                Title: element.name,
                                fldCreatedDate: element.date,
                                fldSampleDescription: element.description,
                                fldMainRequestIDId: response.Id
                            },
                            payload = {
                                listId: REGISTRY_SAMPLES,
                                // данные из хранилища "a-store"
                                jsonBody: data,
                            }
                        this.$store.dispatch('createItem', payload)
                    });
                }
                return response
            })
            // сохраняем исследования
            .then( response => {
                let researches = this.$store.state.a.dataResearches
                if (Object.keys(researches).length != 0) {
                    console.log('Начинаем добавлять исслеодвания...')
                    researches.forEach(element => {
                        let methodicArr = [],
                            metNameArr = []
                        // мтодики
                        for (let i = 0; i < element.methodic.length; i++) {
                            methodicArr.push(element.methodic[i].id)
                        }
                        // наименование методик
                        for (let i = 0; i < element.methodicName.length; i++) {
                            metNameArr.push(element.methodicName[i].id)
                        }
                        let data = {
                                __metadata: {type: 'SP.Data.List8ListItem'},
                                fldDirectionId: element.direction.id,
                                fldMethodId: element.method.id,
                                fldAnalysisTypeId: element.analysisType.id,
                                fldTaskId: element.task.id,
                                fldMethodicId: {
                                    results: methodicArr
                                },
                                fldMethodicNameId: {
                                    results: metNameArr
                                },
                                fldComment: element.comment,
                                fldMainRequestIDId: response.Id
                            },
                            payload = {
                                listId: REGISTRY_REQUEST_FOR_RESEARCHER,
                                // данные из хранилища "a-store"
                                jsonBody: data,
                            }
                        this.$store.dispatch('createItem', payload)
                    });
                }
                return response
            })
            // сохраняем испытания
            .then( response => {
                let tests = this.$store.state.a.dataTests
                if (Object.keys(tests).length != 0) {
                    console.log('Начинаем добавлять испытания...')
                    tests.forEach(element => {
                        let methodicArr = [],
                            metNameArr = []
                        // мтодики
                        for (let i = 0; i < element.methodic.length; i++) {
                            methodicArr.push(element.methodic[i].id)
                        }
                        // наименование методик
                        for (let i = 0; i < element.methodicName.length; i++) {
                            metNameArr.push(element.methodicName[i].id)
                        }
                        let data = {
                                __metadata: {type: 'SP.Data.List9ListItem'},
                                fldTestTypeId: element.testType.id,
                                fldTestMethodId: element.method.id,
                                fldMethodicId: {
                                    results: methodicArr
                                },
                                fldMethodicNameId: {
                                    results: metNameArr
                                },
                                fldComment: element.comment,
                                fldMainRequestIDId: response.Id
                            },
                            payload = {
                                listId: REGISTRY_REQUEST_FOR_TESTER,
                                // данные из хранилища "a-store"
                                jsonBody: data,
                            }
                        this.$store.dispatch('createItem', payload)
                    });
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
    },
}
</script>
