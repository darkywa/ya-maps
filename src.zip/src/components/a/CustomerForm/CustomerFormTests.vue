<template>
    <fieldset>
        <legend>
            Заявки на испытание
        </legend>

        <!-- добавление испытания -->
        <div class="add-new-test text-right mb-4">
            <button @click="showTestModal" type="button" class="btn btn-primary btn-lg">
                <v-icon name="plus-square"/> 
                Добавить испытание
            </button>
        </div>

        <!-- список испытаний -->
        <div class="row">
            <div class="col-sm-12">
                <div v-if="$store.state.a.dataTests != 0" class="tests-items">
                    <div class="samples-item" v-for="(item, index) in $store.state.a.dataTests" :key="item.id">
                        <div class="row">
                            <div class="col-sm-10">
                                <table class="table table-sm table-borderless text-left">
                                    <tr>
                                        <td class="sample-property">Тип испытания</td>
                                        <td>{{ item.testType.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Метод испытания</td>
                                        <td>{{ item.method.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Методика</td>
                                        <td>
                                            <span class="badge badge-primary mr-2" v-for="methodic in item.methodic" :key="methodic.id">
                                                {{ methodic.name }}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Наименвоание методики</td>
                                        <td>
                                            <span class="badge badge-info mr-2" v-for="metName in item.methodicName" :key="metName.id">
                                                {{ metName.name }} 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Комментарий</td>
                                        <td>{{ item.comment }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-sm-2 text-center d-flex align-items-center justify-content-center">
                                <button type="button" class="btn btn-warning mr-2">
                                    <v-icon name="edit"/>
                                </button>
                                <button @click="removeTest(item)" type="button" class="btn btn-danger mr-2">
                                    <v-icon name="trash-alt"/>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else class="alert alert-info" role="alert">
                    <b>Испытания</b> еще не добавлены. Воспользуйтесь кнопкой выше для добавления.
                </div>
            </div>
        </div>

        <!-- модалка -->
        <b-modal size="lg" ref="TestModalRef" centered hide-footer title="Добавление испытания">
            <div class="d-block text-center">

                <!-- тип -->
                <div class="form-group row">
                    <label for="newTestType" class="col-sm-4 col-form-label text-left">Тип испытания</label>
                    <div class="col-sm-8">
                        <select v-model="newTestType" @change="getItemsForTestMethodList" id="newTestType" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in testTypeList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- метод -->
                <div class="form-group row">
                    <label for="newTestMethod" class="col-sm-4 col-form-label text-left">Метод испытания</label>
                    <div class="col-sm-8">
                        <select v-model="newTestMethod" id="newTestMethod" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in testMethodList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- Методика -->
                <div class="form-group row">
                    <label for="newTestMethodic" class="col-sm-4 col-form-label text-left">Методика</label>
                    <div class="col-sm-8">
                        <multiselect
                            v-model="newTestMethodic"
                            :options="testMethodicList" :multiple="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            @close="getItemsForTestMethodicNameList"
                            placeholder="Выбор методик (доступен множественный выбор)"
                            label="name"
                            track-by="name"
                            select-label="Клик мыши или Enter!"
                            deselect-label="Убрать значение"
                            selected-label="Выбрано"
                            :preselect-first="true">
                            <template
                                slot="selection"
                                slot-scope="{ values, search, isOpen }"
                            >
                                <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Методик выбрано ({{ values.length }})</span>
                            </template>
                            <template slot="noResult">
                                Ничего не найдено. Попробуйте изменить запрос.
                            </template>
                            <template slot="noOptions">
                                Данных пока нет
                            </template>
                        </multiselect>
                    </div>
                </div>

                <!-- Наименование методики -->
                <div class="form-group row">
                    <label for="newTestMethodicName" class="col-sm-4 col-form-label text-left">Наименование методики</label>
                    <div class="col-sm-8">
                        <multiselect
                            v-model="newTestMethodicName"
                            :options="testMethodicNameList" :multiple="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Выбор методик (доступен множественный выбор)"
                            label="name"
                            track-by="name"
                            select-label="Клик мыши или Enter!"
                            deselect-label="Убрать значение"
                            selected-label="Выбрано"
                            :preselect-first="true">
                            <template
                                slot="selection"
                                slot-scope="{ values, search, isOpen }"
                            >
                                <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Наименований выбрано ({{ values.length }})</span>
                            </template>
                            <template slot="noResult">
                                Ничего не найдено. Попробуйте изменить запрос.
                            </template>
                            <template slot="noOptions">
                                Данных пока нет
                            </template>
                        </multiselect>
                    </div>
                </div>

                <!-- Наименование условий -->
                <div class="form-group row">
                    <label for="newTestConditionsName" class="col-sm-4 col-form-label text-left">Наименование условий</label>
                    <div class="col-sm-8">
                        <select v-model="newTestConditionsName" @change="getItemsForTestConditionsValuesList" multiple>
                            <option :value="item" v-for="item in testConditionsNameList" :key="item.id">
                                {{item.name}}
                            </option>
                        </select>
                        <!-- <multiselect
                            v-model="newTestConditionsName"
                            @close="getItemsForTestConditionsValuesList"
                            :options="testConditionsNameList" :multiple="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Выбор условий (доступен множественный выбор)"
                            label="name"
                            track-by="name"
                            select-label="Клик мыши или Enter!"
                            deselect-label="Убрать значение"
                            selected-label="Выбрано"
                            :preselect-first="true">
                            <template
                                slot="selection"
                                slot-scope="{ values, search, isOpen }"
                            >
                                <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Условий выбрано ({{ values.length }})</span>
                            </template>
                            <template slot="noResult">
                                Ничего не найдено. Попробуйте изменить запрос.
                            </template>
                            <template slot="noOptions">
                                Данных пока нет
                            </template>
                        </multiselect> -->
                    </div>
                </div>

                <hr>

                <!-- Значения условий -->
                <div class="form-group row">
                    <label for="newTestConditionsName" class="col-sm-4 col-form-label text-left">Значения условий</label>
                    <div class="col-sm-8">
                        <div class="conditions-value">
                            <div class="conditions-item" v-for="(item, index) in groupConditionsName" :key="index">
                                <div class="conditions-item__label">
                                    Условие:
                                </div>
                                <div class="conditions-item__select">
                                    {{groupConditionsName}}
                                    <!-- <multiselect
                                        value=""
                                        :options="groupConditionsName[item.id]" :multiple="true"
                                        :close-on-select="false"
                                        :clear-on-select="false"
                                        :preserve-search="true"
                                        placeholder="Значения условий"
                                        label="name"
                                        track-by="id"
                                        select-label="Клик мыши или Enter!"
                                        deselect-label="Убрать значение"
                                        selected-label="Выбрано"
                                        :preselect-first="false">
                                        <template
                                            slot="selection"
                                            slot-scope="{ values, search, isOpen }"
                                        >
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Значений выбрано ({{ values.length }})</span>
                                        </template>
                                        <template slot="noResult">
                                            Ничего не найдено. Попробуйте изменить запрос.
                                        </template>
                                        <template slot="noOptions">
                                            Данных пока нет
                                        </template>
                                    </multiselect> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr>

                <!-- комментарий -->
                <div class="form-group row">
                    <label for="newTestComment" class="col-sm-4 col-form-label text-left">Комментарий</label>
                    <div class="col-sm-8">
                        <textarea v-model="newTestComment" rows="5" type="text" class="form-control" id="newTestComment"></textarea>
                    </div>
                </div>

            </div>
            <hr>
            <div class="text-right">
                <button type="button" @click="actionThisTest" class="btn btn-success mr-2">
                    <v-icon name="save"/> Сохранить
                </button>
                <button type="button" @click="hideTestModal" class="btn btn-danger">
                    <v-icon name="ban"/> Отмена
                </button>
            </div>
        </b-modal>

    </fieldset>
</template>

<script>

/** Импорт констант */
import {
    HANDBOOK_TESTS_TYPES,
    HANDBOOK_TESTERS_METHOD,
    HANDBOOK_METHODICS,
    HANDBOOK_METHODICS_NAME,
    HANDBOOK_CONDITIONS_NAME,
    HANDBOOK_CONDITIONS_VALUE
} from '../../../constants/constants'

export default {
    data() {
        return {
            tempVal: [],
            options: [
                {id: 1, name: '10 с'},
                {id: 2, name: '20 с'},
                {id: 3, name: '30 с'},
            ],
            tempVal2: [],
            options2: [
                {id: 1, name: 'С надрезом'},
                {id: 2, name: 'Без надреза'},
            ],
            /** значение поля "Тип испытания" при добавлении нового испытания */
            newTestType: '',
            /** значение поля "Метод" при добавлении нового испытания */
            newTestMethod: '',
            /** значение поля "Методика" при добавлении нового испытания */
            newTestMethodic: '',
            /** значение поля "Наименование методики" при добавлении нового испытания */
            newTestMethodicName: [],
            /** значение поля "Наименование условий" при добавлении нового испытания */
            newTestConditionsName: [],
            /** объект для группировки значений условий по имени условия */
            groupConditionsName: [],
            /** данные значений условий при добавлении нового испытания */
            newTestConditionsValues: [],
            /** значение поля "Комментарий" при добавлении нового испытания */
            newTestComment: '',
            /** псевдо-счетчик для кол-ва испытаний */
            counter: 0,
            /** список типов, получаемых из справочника "Типы испытания" */
            testTypeList: null,
            /** список методов, получаемых из справочника "Типы испытания", каскад от "Тип испытания" */
            testMethodList: null,
            /** список методик, получаемых из Справочник «Методики» */
            testMethodicList: [],
            /** список наименования методик, получаемых из Справочник «Наименование методики» */
            testMethodicNameList: [],
            /** список наименования условий, получаемых из Справочник «Наименование условий */
            testConditionsNameList: [],
        }
    },
    methods: {
        /**
         * Получение данных из справочника "Типы испытания"
         * для заполнения поля "тип испытания" при добавлении испытания
         * 
         * @return {void} Обновляет свойство testTypeList
         */
        getItemsForTestTypeList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем типы...' })
            this.$store.dispatch('getList', {
                listId: HANDBOOK_TESTS_TYPES
            })
            .then( response => {
                let arr = response.results
                this.testTypeList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.testTypeList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * При выборе типа при добавлении испытания
         * делаем запрос за методом из Справочника Типы испытаний: Метод
         * по выбранному типу (ID) newTestType
         * 
         * @return {void} Обновляет свойство testTypeList
         */
        getItemsForTestMethodList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем методы...' })
            let typeID = this.newTestType.id,
                payload = {
                    listId: HANDBOOK_TESTERS_METHOD,
                    options: {
                        filter: "(fldTypeID/Id eq '" + typeID + "')"
                    }
                }
            this.$store.dispatch('getList', payload)
            .then( response => {
                let arr = response.results
                this.testMethodList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.testMethodList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение данных из справочника «Методики»
         * для заполнения поля "Методика" при добавлении исследования
         * 
         * @return {void} Обновляет свойство testMethodicList
         */
        getItemsForTestMethodicList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем методики...' })
            this.$store.dispatch('getList', {
                listId: HANDBOOK_METHODICS
            })
            .then( response => {
                let arr = response.results
                this.testMethodicList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.testMethodicList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение данных из справочинка "Наименование методик"
         * для заполнения поля "Наименование методики" при добавлении испытания
         * 
         * @return {void} Обновляет свойство testMethodicNameList
         */
        getItemsForTestMethodicNameList() {
            // если есть выбранные методики
            if (this.newTestMethodic.length != 0) {
                // лоадер
                this.$store.commit('loading', { s: true, m: 'Загружаем наименования методик...' })

                // формируем строку запроса
                let query = ''
                for (let i = 0; i < this.newTestMethodic.length; i++) {
                    query += "(fldMethodicID/Id eq '" + this.newTestMethodic[i].id + "') or "
                }
                // убираем лишнее
                query = query.slice(0, -4)

                let payload = {
                        listId: HANDBOOK_METHODICS_NAME,
                        options: {
                            filter: query
                        }
                    }
                // console.log(methodicArr)
                this.$store.dispatch('getList', payload)
                .then( response => {
                    let arr = response.results
                    this.testMethodicNameList = []
                    // перебираем ответ и кидаем в массив
                    for (let i = 0; i < arr.length; i++) {
                        let obj = {id: arr[i].Id, name: arr[i].Title}
                        this.testMethodicNameList.push(obj)
                    }
                })
                .catch( error => console.log(error) )
                .finally( () => this.$store.commit('loading', {}) )
            } else {
                // очищаем массив с наименованием методик
                this.testMethodicNameList = []
            }
        },
        /**
         * Получение данных из справочника «Наименование условий»
         * для заполнения поля «Наименование условий» при добавлении исследования
         * 
         * @return {void} Обновляет свойство testConditionsNameList
         */
        getItemsForTestConditionsNameList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем наименования значений...' })
            this.$store.dispatch('getList', {
                listId: HANDBOOK_CONDITIONS_NAME
            })
            .then( response => {
                let arr = response.results
                this.testConditionsNameList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    // записываем ID имени значения
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.testConditionsNameList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение данных из справочинка «Значения условий»
         * для заполнения полей "Значения условий" при добавлении испытания
         * 
         * @return {void} Обновляет свойство testMethodicNameList
         */
        getItemsForTestConditionsValuesList() {
            // let arr = [
            //     {
            //         'Температура': [
            //             {id: 1, name: 'Art'},
            //             {id: 1, name: 'An'}
            //         ],
            //     },
            //     {
            //         'Надрез': [
            //             {id: 1, name: 'An'},
            //             {id: 1, name: 'Art'}
            //         ]
            //     }
            // ]
            // console.log(arr)
            this.groupConditionsName = []
            // если есть выбранные методики
            if (this.newTestConditionsName.length != 0) {
                // лоадер
                this.$store.commit('loading', { s: true, m: 'Загружаем значения условий...' })
                // формируем путсыте массивы, имя свойства берется из выбарных имен значений
                for (let i = 0; i < this.newTestConditionsName.length; i++) {
                    let myObj = {}
                    myObj[this.newTestConditionsName[i].id] = []
                    this.groupConditionsName.push(myObj)
                }
                // формируем строку запроса
                let query = ''
                for (let i = 0; i < this.newTestConditionsName.length; i++) {
                    query += "(fldConditionID/Id eq '" + this.newTestConditionsName[i].id + "') or "
                }
                // убираем лишнее
                query = query.slice(0, -4)

                let payload = {
                        listId: HANDBOOK_CONDITIONS_VALUE,
                        options: {
                            //select: 'fldConditionID/Title',
                            filter: query
                        }
                    }
                // console.log(methodicArr)
                this.$store.dispatch('getList', payload)
                .then( response => {
                    let arr = response.results
                    //this.newTestConditionsValues = []
                    // перебираем ответ и кидаем в массив
                    for (let i = 0; i < arr.length; i++) {
                        let obj = {id: arr[i].Id, name: arr[i].Title}
                        // добавляем занчения условий в соответ. имя условия
                        //this.groupConditionsName[arr[i].fldConditionIDId].push(obj)
                    }
                })
                .then(() => console.log(this.groupConditionsName))
                .catch( error => console.log(error) )
                .finally( () => this.$store.commit('loading', {}) )
            } else {
                // очищаем массив с наименованием методик
                this.testMethodicNameList = []
            }
        },
        /**
         * Экшн сохранения данных с модального окна
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataSamples
         */
        actionThisTest() {
            this.$store.state.a.dataTests.push({
                id: this.counter++,
                testType: this.newTestType,
                method: this.newTestMethod,
                methodic: this.newTestMethodic,
                methodicName: this.newTestMethodicName,
                comment: this.newTestComment,
            })
            // закрываем модалку
            this.hideTestModal()
            // сбрасываем поля (?)
            this.newTestType = ''
            this.newTestMethod = ''
            this.newTestMethodic = ''
            this.newTestMethodicName = []
            this.newTestComment = ''
            // сбрасываем массивы, кроме наравлений
            this.testMethodList = []
            this.testMethodicNameList = []
        },
        /**
         * Удаление выбраного элемента из массива образцов
         * 
         * @param {object} item сам образец
         * 
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataTests
         */
        removeTest(item) {
            this.$store.state.a.dataTests.splice(this.$store.state.a.dataTests.indexOf(item), 1)
        },
        /**
         * Показывает окно добавления\редактирования испытания
         */
        showTestModal() {
            this.$refs.TestModalRef.show()
            
            // если типов нет, загружаем
            if (this.testTypeList === null) 
                this.getItemsForTestTypeList()

            // если методик нет, загружаем
            if (this.testMethodicList.length === 0)
                this.getItemsForTestMethodicList()

            // если наименваний условий нет, загружаем их
            if (this.testConditionsNameList.length === 0)
                this.getItemsForTestConditionsNameList()
        },
        /**
         * Скрывает окно добавления\редактирования испытания
         */
        hideTestModal() {
            this.$refs.TestModalRef.hide()
        }
    },
    mounted() {
        
    },
    updated() {
        
    }
}
</script>

<style lang="less">
.conditions-item {
    display: flex;
    align-items: center;
    margin-bottom: 10px;

    &:last-child {
        margin-bottom: 0;
    }

    .conditions-item__label {
        width: 25%;
        text-align: left;
        margin-right: 20px;
        font-weight: bold;
        font-size: .9em;
    }

    .conditions-item__select {
        flex: 1;
    }
}
</style>
