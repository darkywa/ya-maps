<template>
    <fieldset>
        <legend>
            Образцы заявки
        </legend>

        <!-- добавление образца -->
        <div class="add-new-sample text-right mb-4">
            <button @click="showSampleModal" type="button" class="btn btn-primary btn-lg">
                <v-icon name="plus-square"/> 
                Добавить образец
            </button>
        </div>

        <!-- список обрацзов -->
        <div class="row">
            <div class="col-sm-12">
                <div v-if="$store.state.a.dataSamples != 0" class="samples-items">
                    <div class="samples-item" v-for="(item, index) in $store.state.a.dataSamples" :key="item.id">
                        <div class="row">
                            <div class="col-sm-10">
                                <table class="table table-sm table-borderless text-left">
                                    <tr>
                                        <td class="sample-property">Наименвоание образца</td>
                                        <td>{{ item.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Дата изготовления образца</td>
                                        <td>{{ item.date }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Описание образца</td>
                                        <td>{{ item.description }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-sm-2 text-center d-flex align-items-center justify-content-center">
                                <button @click="editSample(item)" type="button" class="btn btn-warning mr-2">
                                    <v-icon name="edit"/>
                                </button>
                                <button @click="removeSample(item)" type="button" class="btn btn-danger mr-2">
                                    <v-icon name="trash-alt"/>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else class="alert alert-info" role="alert">
                    <b>Образцы</b> еще не добавлены. Воспользуйтесь кнопкой выше для добавления.
                </div>
            </div>
        </div>

        <!-- добавление -->
        <b-modal size="lg" ref="SampleModalRef" centered hide-footer title="Добавление образца">
            <div class="d-block text-center">
                <div class="form-group row">
                    <label for="newSampleName" class="col-sm-4 col-form-label text-left">Наименование образца</label>
                    <div class="col-sm-8">
                        <input v-model="newSampleName" type="text" class="form-control" id="newSampleName">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="newSampleDate" class="col-sm-4 col-form-label text-left">Дата изготовления образца</label>
                    <div class="col-sm-8">
                        <date-picker
                            v-model="newSampleDate"
                            type="text"
                            class="form-control"
                            id="newSampleDate"
                            :config="{
                                format: 'MM/DD/YYYY',
                                useCurrent: false,
                                locale: 'ru',
                            }"
                        />
                    </div>
                </div>
                <div class="form-group row">
                    <label for="newSampleDescription" class="col-sm-4 col-form-label text-left">Описание образца</label>
                    <div class="col-sm-8">
                        <textarea v-model="newSampleDescription" rows="5" type="text" class="form-control" id="newSampleDescription"></textarea>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-right">
                <button type="button" @click="actionThisSample" class="btn btn-success mr-2">
                    <v-icon name="save"/> Сохранить
                </button>
                <button type="button" @click="hideSampleModal" class="btn btn-danger">
                    <v-icon name="ban"/> Отмена
                </button>
            </div>
        </b-modal>

        <!-- редактирование -->
        <b-modal size="lg" ref="SampleModalEdit" centered hide-footer title="Редактирование образца">
            <div class="d-block text-center">
                <div class="form-group row">
                    <label for="editSampleName" class="col-sm-4 col-form-label text-left">Наименование образца</label>
                    <div class="col-sm-8">
                        <input v-model="editSampleName" type="text" class="form-control" id="editSampleName">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="editSampleDate" class="col-sm-4 col-form-label text-left">Дата изготовления образца</label>
                    <div class="col-sm-8">
                        <date-picker
                            v-model="editSampleDate"
                            type="text"
                            class="form-control"
                            id="editSampleDate"
                            :config="{
                                format: 'MM/DD/YYYY',
                                useCurrent: false,
                                locale: 'ru',
                            }"
                        />
                    </div>
                </div>
                <div class="form-group row">
                    <label for="editSampleDescription" class="col-sm-4 col-form-label text-left">Описание образца</label>
                    <div class="col-sm-8">
                        <textarea v-model="editSampleDescription" rows="5" type="text" class="form-control" id="editSampleDescription"></textarea>
                    </div>
                </div>
                <input type="hidden" v-model="editItemID" />
                <input type="hidden" v-model="editItemObject" />
            </div>
            <hr>
            <div class="text-right">
                <button type="button" @click="saveEditSample" class="btn btn-success mr-2">
                    <v-icon name="save"/> Сохранить
                </button>
                <button type="button" @click="hideEditSampleModal" class="btn btn-danger">
                    <v-icon name="ban"/> Отмена
                </button>
            </div>
        </b-modal>

    </fieldset>
</template>

<script>

/** Импорт констант */
//import {  } from '../../../constants/constants'

export default {
    data() {
        return {
            /** Значение поля "Наименвоание образца" при добавлении нового образца */
            newSampleName: '',
            /** Значение поля "Дата" при добавлении нового образца */
            newSampleDate: '',
            /** Значение поля "Описание" при добавлении нового образца */
            newSampleDescription: '',
            /** псевдо-счетчик для кол-ва образцов */
            counter: 0,
            editItemObject: null,
            editItemID: '',
            editSampleName: '',
            editSampleDate: '',
            editSampleDescription: '',
        }
    },
    methods: {
        /**
         * Экшн сохранения данных с модального окна добавления
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataSamples
         */
        actionThisSample() {
            this.$store.state.a.dataSamples.push({
                id: this.counter++,
                name: this.newSampleName,
                date: this.newSampleDate,
                description: this.newSampleDescription
            })
            this.hideSampleModal()
            this.newSampleName = this.newSampleDate = this.newSampleDescription = ''
        },
        /**
         * Экшн сохранения данных с модального окна редактирования
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataSamples
         */
        saveEditSample() {
            let items = this.$store.state.a.dataSamples,
                index = items.indexOf(this.editItemObject),
                obj = {
                    id: this.editItemID,
                    name: this.editSampleName,
                    date: this.editSampleDate,
                    description: this.editSampleDescription
                }
            if (index !== -1) {
                items[index] = obj
            }
            this.hideEditSampleModal()
            this.editSampleName = this.editSampleDate = this.editSampleDescription = ''
        },
        /**
         * Удаление выбраного элемента из массива образцов
         * 
         * @param {object} item сам образец
         * 
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataSamples
         */
        removeSample(item) {
            this.$store.state.a.dataSamples.splice(this.$store.state.a.dataSamples.indexOf(item), 1)
        },
        /**
         * Изменение выбранного элемента образца
         * 
         * @param {object} item сам образец
         * 
         * @returns {void} обновляет свойства значения полей формы редактирования
         */
        editSample(item) {
            // открываем модалку
            this.showEditSampleModal()
            // заполняем данными форму редактирования
            this.editItemObject = item
            this.editItemID = item.id
            this.editSampleName = item.name
            this.editSampleDate = item.date
            this.editSampleDescription = item.description
        },
        /**
         * Показывает окно добавления образца
         */
        showSampleModal() {
            this.$refs.SampleModalRef.show()
        },
        /**
         * Скрывает окно добавления образца
         */
        hideSampleModal() {
            this.$refs.SampleModalRef.hide()
        },
        /**
         * Показывает окно добавления образца
         */
        showEditSampleModal() {
            this.$refs.SampleModalEdit.show()
        },
        /**
         * Скрывает окно добавления образца
         */
        hideEditSampleModal() {
            this.$refs.SampleModalEdit.hide()
        }
    },
    mounted() {
        
    },
    updated() {
        
    }
}
</script>
