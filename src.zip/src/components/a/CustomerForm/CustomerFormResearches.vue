<template>
    <fieldset>
        <legend>
            Заявки на исследование
        </legend>

        <!-- добавление исследования -->
        <div class="add-new-research text-right mb-4">
            <button @click="showResearchModal" type="button" class="btn btn-primary btn-lg">
                <v-icon name="plus-square"/> 
                Добавить исследование
            </button>
        </div>

        <!-- список исследований -->
        <div class="row">
            <div class="col-sm-12">
                <div v-if="$store.state.a.dataResearches != 0" class="researches-items">
                    <div class="samples-item" v-for="(item, index) in $store.state.a.dataResearches" :key="index">
                        <div class="row">
                            <div class="col-sm-10">
                                <table class="table table-sm table-borderless text-left">
                                    <tr>
                                        <td class="sample-property">Направление</td>
                                        <td>{{ item.direction.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Метод</td>
                                        <td>{{ item.method.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Тип анализа</td>
                                        <td>
                                            <span v-if="item.analysisType.name">
                                                {{ item.analysisType.name }}
                                            </span>
                                            <span v-else class="badge badge-warning">
                                                Тип анализа не задан
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Задача</td>
                                        <td>{{ item.task.name }}</td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Методика</td>
                                        <td>
                                            <span class="badge badge-primary mr-2" v-for="methodic in item.methodic" :key="methodic.id">
                                                {{ methodic.name }}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Наименвоание методики</td>
                                        <td>
                                            <span class="badge badge-info mr-2" v-for="metName in item.methodicName" :key="metName.id">
                                                {{ metName.name }} 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="sample-property">Комментарий</td>
                                        <td>{{ item.comment }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-sm-2 text-center d-flex align-items-center justify-content-center">
                                <button type="button" class="btn btn-warning mr-2">
                                    <v-icon name="edit"/>
                                </button>
                                <button @click="removeResearch(item)" type="button" class="btn btn-danger mr-2">
                                    <v-icon name="trash-alt"/>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else class="alert alert-info" role="alert">
                    <b>Исследования</b> еще не добавлены. Воспользуйтесь кнопкой выше для добавления.
                </div>
            </div>
        </div>

        <!-- модалка -->
        <b-modal size="lg" ref="ResearchModalRef" centered hide-footer title="Добавление исследования">
            <div class="d-block text-center">

                <!-- направления -->
                <div class="form-group row">
                    <label for="newResearchDirection" class="col-sm-4 col-form-label text-left">Направление</label>
                    <div class="col-sm-8">
                        <select v-model="newResearchDirection" @change="getItemsForResearchMethodList" id="newResearchDirection" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in researchDirectionList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- метод -->
                <div class="form-group row">
                    <label for="newResearchMethod" class="col-sm-4 col-form-label text-left">Метод</label>
                    <div class="col-sm-8">
                        <select v-model="newResearchMethod" @change="getAnalysisAndTask" id="newResearchMethod" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in researchMethodList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- тип анализа -->
                <div class="form-group row">
                    <label for="newResearchAnalysisType" class="col-sm-4 col-form-label text-left">Тип анализа</label>
                    <div class="col-sm-8">
                        <select v-model="newResearchAnalysisType" id="newResearchAnalysisType" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in researchAnalysisTypeList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- задача -->
                <div class="form-group row">
                    <label for="newResearchTask" class="col-sm-4 col-form-label text-left">Задача</label>
                    <div class="col-sm-8">
                        <select v-model="newResearchTask" id="newResearchTask" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="item in researchTaskList"
                                :key="item.id"
                                :value="item"
                            >
                                {{ item.name }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- Методика -->
                <div class="form-group row">
                    <label for="newResearchMethodic" class="col-sm-4 col-form-label text-left">Методика</label>
                    <div class="col-sm-8">
                        <multiselect
                            v-model="newResearchMethodic"
                            :options="researchMethodicList" :multiple="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            @close="getItemsForResearchMethodicNameList"
                            placeholder="Выбор методик (доступен множественный выбор)"
                            label="name"
                            track-by="name"
                            select-label="Клик мыши или Enter!"
                            deselect-label="Убрать значение"
                            selected-label="Выбрано"
                            :preselect-first="false">
                            <template
                                slot="selection"
                                slot-scope="{ values, search, isOpen }"
                            >
                                <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Методик выбрано ({{ values.length }})</span>
                            </template>
                            <template slot="noResult">
                                Ничего не найдено. Попробуйте изменить запрос.
                            </template>
                            <template slot="noOptions">
                                Данных пока нет
                            </template>
                        </multiselect>
                    </div>
                </div>

                <!-- Наименование методики -->
                <div class="form-group row">
                    <label for="newResearchMethodicName" class="col-sm-4 col-form-label text-left">Наименование методики</label>
                    <div class="col-sm-8">
                        <multiselect
                            v-model="newResearchMethodicName"
                            :options="researchMethodicNameList" :multiple="true"
                            :close-on-select="false"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Наименование методик (доступен множественный выбор)"
                            label="name"
                            track-by="name"
                            select-label="Клик мыши или Enter!"
                            deselect-label="Убрать значение"
                            selected-label="Выбрано"
                            :preselect-first="false">
                            <template
                                slot="selection"
                                slot-scope="{ values, search, isOpen }"
                            >
                                <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">Наименоваий выбрано ({{ values.length }})</span>
                            </template>
                            <template slot="noResult">
                                Ничего не найдено. Попробуйте изменить запрос.
                            </template>
                            <template slot="noOptions">
                                Данных пока нет
                            </template>
                        </multiselect>
                    </div>
                </div>

                <!-- комментарий -->
                <div class="form-group row">
                    <label for="newResearchComment" class="col-sm-4 col-form-label text-left">Комментарий</label>
                    <div class="col-sm-8">
                        <textarea v-model="newResearchComment" rows="5" type="text" class="form-control" id="newResearchComment"></textarea>
                    </div>
                </div>

            </div>
            <hr>
            <div class="text-right">
                <button type="button" @click="actionThisResearch" class="btn btn-success mr-2">
                    <v-icon name="save"/> Сохранить
                </button>
                <button type="button" @click="hideResearchModal" class="btn btn-danger">
                    <v-icon name="ban"/> Отмена
                </button>
            </div>
        </b-modal>

    </fieldset>
</template>

<script>

/** Импорт констант */
import {
    HANDBOOK_RESEARCHS_TYPES,
    HANDBOOK_RESEARCHES_METHOD,
    HANDBOOK_RESEARCHES_ANALYSIS,
    HANDBOOK_RESEARCHES_TASK,
    HANDBOOK_METHODICS,
    HANDBOOK_METHODICS_NAME
} from '../../../constants/constants'

export default {
    data() {
        return {
            /** значение поля "Направление" при добавлении нового исследования */
            newResearchDirection: '',
            /** значение поля "Метод" при добавлении нового исследования */
            newResearchMethod: '',
            /** значение поля "Тип анализа" при добавлении нового исследования */
            newResearchAnalysisType: '',
            /** значение поля "Задача" при добавлении нового исследования */
            newResearchTask: '',
            /** значение поля "Методика" при добавлении нового исследования */
            newResearchMethodic: [],
            /** значение поля "Наименование методики" при добавлении нового исследования */
            newResearchMethodicName: [],
            /** значение поля "Комментарий" при добавлении нового исследования */
            newResearchComment: '',
            /** псевдо-счетчик для кол-ва исследований */
            counter: 0,
            /** список направлений, получаемых из справочника "Типы исследования" */
            researchDirectionList: null,
            /** список методов, получаемых из справочника "Типы исследования", каскад от "Направление" */
            researchMethodList: null,
            /** список типов анализа, получаемых из справочника "Типы исследования", каскад от "Метод" */
            researchAnalysisTypeList: null,
            /** список задач, получаемых из справочника "Типы исследования", каскад от "Тип анализа" */
            researchTaskList: null,
            /** список методик, получаемых из Справочник «Методики» */
            researchMethodicList: [],
            /** список наименования методик, получаемых из Справочник «Наименование методики» */
            researchMethodicNameList: [],
        }
    },
    methods: {
        /**
         * Получение данных из справочника "Типы исследования"
         * для заполнения поля "направление" при добавлении исследования
         * 
         * @return {void} Обновляет свойство researchDirectionList
         */
        getItemsForResearchDirectionList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем направления...' })
            this.$store.dispatch('getList', {
                listId: HANDBOOK_RESEARCHS_TYPES
            })
            .then( response => {
                let arr = response.results
                this.researchDirectionList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].fldDirection}
                    this.researchDirectionList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * При выборе направления при добавлении исследования
         * делаем запрос за методом из Справочника «Типы исследований: Метод»
         * по выбранному направлению (ID) newResearchDirection
         * 
         * @return {void} Обновляет свойство researchMethodList
         */
        getItemsForResearchMethodList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем методы...' })
            let dirID = this.newResearchDirection.id,
                payload = {
                    listId: HANDBOOK_RESEARCHES_METHOD,
                    options: {
                        filter: "(fldDirectionID/Id eq '" + dirID + "')"
                    }
                }
            this.$store.dispatch('getList', payload)
            .then( response => {
                let arr = response.results
                this.researchMethodList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.researchMethodList.push(obj)
                }
                // фильтруем до уникальных данных
                this.researchMethodList = this.researchMethodList.filter((v, i, a) => a.indexOf(v) === i)
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение типа анализа и задачи, при выборе метода
         */
        getAnalysisAndTask() {
            this.getItemsForResearchAnalysisList()
            this.getItemsForResearchTaskList()
        },
        /**
         * При выборе метода при добавлении исследования
         * делаем запрос за типом анализа из Типы исследований: Тип анализа
         * по выбранному методу (ID) newResearchMethod
         * 
         * @return {void} Обновляет свойство researchAnalysisTypeList
         */
        getItemsForResearchAnalysisList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем типы анализов...' })
            let methodID = this.newResearchMethod.id,
                payload = {
                    listId: HANDBOOK_RESEARCHES_ANALYSIS,
                    options: {
                        filter: "(fldMethodID/Id eq '" + methodID + "')"
                    }
                }
            this.$store.dispatch('getList', payload)
            .then( response => {
                let arr = response.results
                this.researchAnalysisTypeList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.researchAnalysisTypeList.push(obj)
                }
                // фильтруем до уникальных данных
                this.researchAnalysisTypeList = this.researchAnalysisTypeList.filter((v, i, a) => a.indexOf(v) === i)
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * При выборе метода при добавлении исследования
         * делаем запрос за задачей из Справочника Типы исследований: Задача
         * по выбранному методу (ID) newResearchMethod
         * 
         * @return {void} Обновляет свойство researchTaskList
         */
        getItemsForResearchTaskList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем типы анализов...' })
            let methodID = this.newResearchMethod.id,
                payload = {
                    listId: HANDBOOK_RESEARCHES_TASK,
                    options: {
                        filter: "(fldMethodID/Id eq '" + methodID + "')"
                    }
                }
            this.$store.dispatch('getList', payload)
            .then( response => {
                let arr = response.results
                this.researchTaskList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.researchTaskList.push(obj)
                }
                // фильтруем до уникальных данных
                this.researchTaskList = this.researchTaskList.filter((v, i, a) => a.indexOf(v) === i)
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение данных из справочника «Методики»
         * для заполнения поля "Методика" при добавлении исследования
         * 
         * @return {void} Обновляет свойство researchMethodicList
         */
        getItemsForResearchMethodicList() {
            // лоадер
            this.$store.commit('loading', { s: true, m: 'Загружаем методики...' })
            this.$store.dispatch('getList', {
                listId: HANDBOOK_METHODICS
            })
            .then( response => {
                let arr = response.results
                this.researchMethodicList = []
                // перебираем ответ и кидаем в массив
                for (let i = 0; i < arr.length; i++) {
                    let obj = {id: arr[i].Id, name: arr[i].Title}
                    this.researchMethodicList.push(obj)
                }
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.commit('loading', {}) )
        },
        /**
         * Получение данных из справочинка "Наименование методик"
         * для заполнения поля "Наименование методики" при добавлении исследования
         * 
         * @return {void} Обновляет свойство researchMethodicNameList
         */
        getItemsForResearchMethodicNameList() {
            // если есть выбранные методики
            if (this.newResearchMethodic.length != 0) {
                // лоадер
                this.$store.commit('loading', { s: true, m: 'Загружаем наименования методик...' })

                // формируем строку запроса
                let query = ''
                for (let i = 0; i < this.newResearchMethodic.length; i++) {
                    query += "(fldMethodicID/Id eq '" + this.newResearchMethodic[i].id + "') or "
                }
                // убираем лишнее
                query = query.slice(0, -4)

                let payload = {
                        listId: HANDBOOK_METHODICS_NAME,
                        options: {
                            filter: query
                        }
                    }
                // console.log(methodicArr)
                this.$store.dispatch('getList', payload)
                .then( response => {
                    let arr = response.results
                    this.researchMethodicNameList = []
                    // перебираем ответ и кидаем в массив
                    for (let i = 0; i < arr.length; i++) {
                        let obj = {id: arr[i].Id, name: arr[i].Title}
                        this.researchMethodicNameList.push(obj)
                    }
                })
                .catch( error => console.log(error) )
                .finally( () => this.$store.commit('loading', {}) )
            } else {
                // очищаем массив с наименованием методик
                this.researchMethodicNameList = []
            }
        },
        /**
         * Экшн сохранения данных с модального окна
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataSamples
         */
        actionThisResearch() {
            this.$store.state.a.dataResearches.push({
                id: this.counter++,
                direction: this.newResearchDirection,
                method: this.newResearchMethod,
                analysisType: this.newResearchAnalysisType,
                task: this.newResearchTask,
                methodic: this.newResearchMethodic,
                methodicName: this.newResearchMethodicName,
                comment: this.newResearchComment,
            })
            
            // закрываем модалку
            this.hideResearchModal()
            // сбрасываем поля (?)
            this.newResearchDirection = ''
            this.newResearchMethod = ''
            this.newResearchAnalysisType = ''
            this.newResearchTask = ''
            this.newResearchMethodic = []
            this.newResearchMethodicName = []
            this.newResearchComment = ''
            // сбрасываем массивы, кроме наравлений
            this.researchMethodList = null
            this.researchAnalysisTypeList = null
            this.researchTaskList = null
            this.researchMethodicNameList = []
        },
        /**
         * Удаление выбраного элемента из массива образцов
         * 
         * @param {object} item сам образец
         * 
         * @returns {void} обновляет свойство хранилища А - $store.state.a.dataResearches
         */
        removeResearch(item) {
            this.$store.state.a.dataResearches.splice(this.$store.state.a.dataResearches.indexOf(item), 1)
        },
        /**
         * Показывает окно добавления\редактирования исследования
         * и загружает данные по направлениям и методикам
         */
        showResearchModal() {
            this.$refs.ResearchModalRef.show()

            // если направлений нет, загружаем
            if (this.researchDirectionList === null) 
                this.getItemsForResearchDirectionList()

            // если методик нет, загружаем
            if (this.researchMethodicList.length === 0)
                this.getItemsForResearchMethodicList()
        },
        /**
         * Скрывает окно добавления\редактирования исследования
         */
        hideResearchModal() {
            this.$refs.ResearchModalRef.hide()
        }
    },
    mounted() {
        
    },
    updated() {
        
    }
}
</script>

<style lang="less" scoped>
.methodic-text {

}
</style>
