<template>
    <fieldset>
        <legend>
            Базовая информация о заявке
        </legend>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="form-group row">
                    <label for="BaseProject" class="col-sm-4 col-form-label text-left">Проект</label>
                    <div class="col-sm-8">
                        <select v-model="BaseProjectIndex" @change="getItemForPriority()" id="BaseProject" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="(item, index) in baseProjecstList"
                                :key="item.ID"
                                :value="index"
                            >
                                {{ item.Title }}
                            </option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseDirection" class="col-sm-4 col-form-label text-left">Дирекция<br><br></label>
                    <div class="col-sm-8">
                        <select v-model="BaseDirectionIndex" @change="getItemForBasePerDir()" id="BaseDirection" class="form-control">
                            <option selected disabled>Выбор...</option>
                            <option 
                                v-for="(item, index) in baseDirectionsList"
                                :key="item.ID"
                                :value="index"
                            >
                                {{ item.fldDirection }}
                            </option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseWorkPurpose" class="col-sm-4 col-form-label text-left">Цель работ</label>
                    <div class="col-sm-8">
                        <input v-model="BaseWorkPurpose" type="text" class="form-control" id="BaseWorkPurpose">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseBasisOfOrder" class="col-sm-4 col-form-label text-left">Основание для заказа</label>
                    <div class="col-sm-8">
                        <input v-model="BaseBasisOfOrder" type="text" class="form-control" id="BaseBasisOfOrder">
                    </div>
                </div>
                <div class="form-group row text-left">
                    <label for="BaseWorkPurpose" class="col-sm-4 col-form-label text-left">Отчет и протокол</label>
                    <div class="col-sm-8">
                        <div class="form-check">
                            <input v-model="BaseProtocol" class="form-check-input" type="checkbox" id="BaseProtocol">
                            <label class="form-check-label" for="BaseProtocol">
                                Протокол
                            </label>
                        </div>
                        <div class="form-check">
                            <input v-model="BaseReport" class="form-check-input" type="checkbox" id="BaseReport">
                            <label class="form-check-label" for="BaseReport">
                                Отчет
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="form-group row">
                    <label for="BasePriority" class="col-sm-4 col-form-label text-left">Приоритет</label>
                    <div class="col-sm-8">
                        <input type="text" v-model="BasePriorityValue" id="BasePriority" disabled class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BasePerDirValue" class="col-sm-4 col-form-label text-left">Перспективное направление</label>
                    <div class="col-sm-8">
                        <input type="text" v-model="BasePerDirValue" id="BasePerDirValue" class="form-control" disabled>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseTerm" class="col-sm-4 col-form-label text-left">Срок</label>
                    <div class="col-sm-8">
                        <date-picker
                            v-model="BaseTerm"
                            type="text"
                            class="form-control"
                            id="BaseTerm"
                            :config="{
                                format: 'MM/DD/YYYY',
                                useCurrent: false,
                                locale: 'ru',
                            }"
                        />
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseStatus" class="col-sm-4 col-form-label text-left">Статус</label>
                    <div class="col-sm-8">
                        <input type="text" v-model="BaseStatus" id="BaseStatus" disabled class="form-control">
                    </div>
                </div>
            </div>
        </div>
    </fieldset>
</template>

<script>
/** Импорт констант */
import {
    SERVER_URL,
    HANDBOOK_PROJECT,
    HANDBOOK_PERSPECTIVE_DIRECTIONS,
} from '../../../constants/constants'

export default {
    data() {
        return {
            /** список проектов, получаемый из справочника */
            baseProjecstList: null,
            /** список дирекций, получаемый из справочника */
            baseDirectionsList: null,
            /** хранилище для Названия выбранного "Проект" */
            BaseProject: '',
            /** хранилище для Названия выбранного "Дирекция" */
            BaseDirection: '',
            /** хранилище для базового поля "Перспективное направление", каскад от базового "Дирекция" */
            BasePerDirValue: '',
            /** хранилище для базового поля "Приоритет", каскад от базового "Проекты" */
            BasePriorityValue: '',
            /** хранилище для базового поля "Проекты", содержит индекс для массива baseProjecstList */
            BaseProjectIndex: '',
            /** хранилище для базового поля "Дирекция", содержит индекс для массива baseDirectionsList */
            BaseDirectionIndex: '',
            /** хранилище для базового поля "Цель работ" */
            BaseWorkPurpose: '',
            /** хранилище для базового поля "Основание для заказа" */
            BaseBasisOfOrder: '',
            /** хранилище для базового поля "Срок" */
            BaseTerm: '',
            /** хранилище для базового поля "Статус" */
            BaseStatus: '',
            /** хранилище для базового поля "Протокол" */
            BaseProtocol: '',
            /** хранилище для базового поля "Отчеет" */
            BaseReport: '',
        }
    },
    methods: {
        /**
         * Получение данных из справочника "Проекты"
         * для заполнения базового поля "Проект"
         * 
         * @return {void} Обновляет свойство baseProjecstList
         */
        getItemsForBaseProjectsList() {
            this.$store.state.isLoading = true
            this.$store.dispatch('getList', {
                listId: HANDBOOK_PROJECT
            })
            .then( response => {
                this.baseProjecstList = []
                let items = response.results;
                items.forEach(element => this.baseProjecstList.push(element))
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.state.isLoading = false )
        },
        /**
         * Получение данных из справочника "Перспективные направления"
         * для заполнения базового поля "Дирекция"
         * 
         * @return {void} Обновляет свойство baseDirectionsList
         */
        getItemsForBaseDirectionList() {
            this.$store.state.isLoading = true
            this.$store.dispatch('getList', {
                listId: HANDBOOK_PERSPECTIVE_DIRECTIONS
            })
            .then( response => {
                this.baseDirectionsList = []
                let items = response.results;
                items.forEach(element => this.baseDirectionsList.push(element))
            })
            .catch( error => console.log(error) )
            .finally( () => this.$store.state.isLoading = false )
        },
        /**
         * Берем значение базового "Дирекция", оно явялется индексом (чтобы не делать лишний запрос к бд)
         * И по индексу извлекаем название перспективного направления для базового поля
         * 
         * @return {void} Обновляет свойство BasePerDirValue
         */
        getItemForBasePerDir() {
            let index = this.BaseDirectionIndex
            this.BasePerDirValue = this.baseDirectionsList[index].Id
            this.BaseDirection = this.baseDirectionsList[index].Id
        },
        /**
         * Берем значение базового "Проекты", оно явялется индексом (чтобы не делать лишний запрос к бд)
         * И по индексу извлекаем название перспективного направления для базового поля
         * 
         * @return {void} Обновляет свойство BasePriorityValue
         */
        getItemForPriority() {
            let index = this.BaseProjectIndex
            this.BasePriorityValue = this.baseProjecstList[index].fldPriority
            this.BaseProject = this.baseProjecstList[index].Id
        },
    },
    mounted() {
        // получаем данные со справочников для базовых полей
        this.getItemsForBaseProjectsList()
        this.getItemsForBaseDirectionList()
        // Защита от записи (?)
        Object.defineProperty(this, 'BaseStatus', {value: 'Новый', writable: false})
    },
    updated() {
        // данные базовых полей с основной формы
        this.$store.state.a.dataFromBaseForm = {
            __metadata: {type: 'SP.ListItem'},
            Title: 'Пока без названия ' + (Math.random() * 100).toFixed(2), // тут будет код заявки
            fldProjectId: this.BaseProject,
            fldPerspectiveDirectionId: this.BasePerDirValue,
            fldDirectionId: this.BaseDirection,
            fldOrderBasis: this.BaseBasisOfOrder,
            fldWorkPurpose: this.BaseWorkPurpose,
            fldTerm: this.BaseTerm,
            fldStatus: this.BaseStatus,
            fldPriority: this.BasePriorityValue,
            // fldProtocol: this.BaseProtocol,
            // fldReport: this.BaseReport,
        }
    }
}
</script>
