<template>
    <fieldset>
        <button type="button" @click="addNewBaseRequest()" class="btn btn-success mr-2">
            <v-icon name="check"/> Отправить
        </button>
        <button type="button" class="btn btn-primary mr-2">
            <v-icon name="save"/> Сохранить
        </button>
    </fieldset>
</template>

<script>
export default {
    methods: {
        /**
         * Запрос на добавлени в список «Реестр заявок» для заявителя и регистратора
         * Пока не определился с ответом
         */
        addNewBaseRequest() {
            this.$store.state.isLoading = true
            let _this = this,
                indexDirection = this.BaseDirection,
                indexProject = this.BaseProject
            
            this.$store.dispatch('createItem', {
                listId: REGISTRY_REQUEST_FOR_CUSTOMER,
                jsonBody: {
                    __metadata: {type: 'SP.ListItem'},
                    Title: 'Пока без названия', // тут будет код заявки
                    fldProject: this.baseProjecstList[indexProject].Title,
                    fldPerspectiveDirection: this.BasePerDirValue,
                    fldDirection: this.baseDirectionsList[indexDirection].fldDirection,
                    fldOrderBasis: this.BaseBasisOfOrder,
                    fldWorkPurpose: this.BaseWorkPurpose,
                    fldTerm: this.BaseTerm,
                    fldStatus: this.BaseStatus,
                    fldPriority: this.BasePriorityValue,
                }
            })
            .then( response => {
                console.log(response)
            })
            .then( () => this.$store.state.isLoading = false )
            .catch( error => console.error(error) )
        },
    },
}
</script>
