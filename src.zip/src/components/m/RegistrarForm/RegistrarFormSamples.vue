<template>
    <fieldset>
        <legend>
            Образцы заявки
        </legend>
        <div class="row">
            <div class="col-sm-12">
                <div class="samples-item" v-for="item in samplesList" :key="item.ID">
                    <div class="row">
                        <div class="col-sm-10">
                            <table class="table table-sm table-borderless text-left">
                                <tr>
                                    <td class="sample-property">Наименование образца</td>
                                    <td>{{item.Title}}</td>
                                </tr>
                                <tr>
                                    <td class="sample-property">Дата изготовления образца</td>
                                    <td>{{item.fldCreatedDate}}</td>
                                </tr>
                                <tr>
                                    <td class="sample-property">Описание образца</td>
                                    <td>{{item.fldSampleDescription}}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </fieldset>
</template>

<script>

    /** Импорт констант */
    import {REGISTRY_SAMPLES} from '../../../constants/constants'

    export default {
        props: [
            /** хранилище для ID основной заявки, получаемой из справочника */
            'baseItemId',
        ],
        data() {
            return {
                /** список образцов, получаемый из справочника */
                samplesList: null,
            }
        },
        methods: {
            /**
             * Получение элементов из справочника «Реестр образцов» для общих заявок
             * для вывода на страницу
             *
             * @return {void} Обновляет список samplesList
             */
            getItemsForSamplesList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                const payload = {
                    listId: REGISTRY_SAMPLES,
                    options: {
                        filter: 'fldMainRequestID/Id eq \'' + this.baseItemId + '\''
                    }
                }

                this.$store.dispatch('getList', payload)
                    .then((res) => this.samplesList = res.results)
                    .catch(error => console.error(error))
                    .finally(() => this.$store.state.isLoading = false);

            }
        },
        mounted() {
            // получаем заявку
            this.getItemsForSamplesList()
        }

    }
</script>
