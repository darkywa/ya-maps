<template>
    <fieldset>
        <legend>
            Заявки на исследование
        </legend>
        <div class="row">
            <div class="col-sm-12" v-if="researchesList.length !== 0">
                <div class="samples-item" v-for="item in researchesList" :key="item.ID">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="samples-modal-item">
                                <div class="form-group row">
                                    <label for="ResearchDirection"
                                           class="col-sm-4 col-form-label text-left">Направление</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchDirection"
                                               :value="item.fldDirection"
                                               readonly placeholder="Не заполнено">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchMethod" class="col-sm-4 col-form-label text-left">Метод</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchMethod"
                                               :value="item.fldMethod"
                                               readonly placeholder="Не заполнено">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchComment"
                                           class="col-sm-4 col-form-label text-left">Комментарий</label>
                                    <div class="col-sm-8">
                                        <textarea type="text" class="form-control" id="ResearchComment"
                                               :value="item.fldComment"
                                                  readonly placeholder="Не заполнено" rows="4"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchMethodic"
                                           class="col-sm-4 col-form-label text-left">Методика</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchMethodic"
                                               :value="item.fldMethodic"
                                               placeholder="Не заполнено">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchMethodicName" class="col-sm-4 col-form-label text-left">Наименование
                                        методики</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchMethodicName"
                                               :value="item.fldMethodicName"
                                               placeholder="Не заполнено">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group row">
                                <label for="ResearchAnalysisType" class="col-sm-4 col-form-label text-left">Тип
                                    анализа</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchAnalysisType"
                                           :value="item.fldAnalysisType"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchTask" class="col-sm-4 col-form-label text-left">Задача</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchTask" :value="item.fldTask"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchStatus" class="col-sm-4 col-form-label text-left">Статус</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchStatus"
                                           :value="item.fldStatus"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchDevice" class="col-sm-4 col-form-label text-left">Прибор</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchDevice"
                                           v-model="item.fldDevice"
                                           placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchResponsible"
                                       class="col-sm-4 col-form-label text-left">Ответственный</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchResponsible"
                                           :value="responsibleInfo[item.fldResponsibleId]"
                                           placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchPrice"
                                       class="col-sm-4 col-form-label text-left">Стоимость</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchPrice"
                                           :value="item.fldPrice"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- экшены формы -->
                    <RegistrarFormActions/>
                    <RegistrarFormResults/>
                </div>
            </div>
            <div v-else class="alert alert-info col-md-12" role="alert">
                Исследования не найдены <br> Проверьте являетесь ли вы ответственным по данной заявке или регистратором по данному направлению
            </div>
        </div>
    </fieldset>
</template>

<script>

    /** Импорт экшенов формы */
    import RegistrarFormActions from './RegistrarFormActions'
    /** Импорт испытателей */
    import RegistrarFormResults from './RegistrarFormResults.vue'
    /** Импорт констант */
    import {REGISTRY_REQUEST_FOR_RESEARCHER} from '../../../constants/constants'

    export default {
        props: [
            /** хранилище для ID основной заявки, получаемой из справочника */
            'baseItemId',
            /** хранилище для ID направлений доступных текущему пользователю, получаемый из справочника */
            'directionListId',
            /** хранилище для ID текущего пользователя, получаемый с сервера */
            'currentUserId',
        ],
        components: {
            RegistrarFormActions,
            RegistrarFormResults,
        },
        data() {
            return {
                /** список дирекций, получаемый из справочника */
                researchesList: [],
                /** карта ответственных: id: info */
                responsibleInfo: {},
            }
        },
        methods: {
            /**
             * Получение элементов из справочника «Реестр заявок» для исполнителя заявок на исследования
             * для вывода на страницу
             *
             * @return {void} Обновляет список researchesList
             */
            getItemsForResearchesList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                let filter = 'fldMainRequestID/Id eq \'' + this.baseItemId + '\'';
                filter += ' and ';
                if(!this.directionListId.length == 0) {
                    filter += '(';
                    this.directionListId.forEach((id, index, array) => {
                        filter += 'fldDirection/Id eq \'' + id + '\'';
                        if(index !== (array.length-1)){
                            filter += ' or ';
                        }
                    });
                    filter += ')';
                } else {
                    filter += 'fldResponsible/Id eq \'' + this.currentUserId + '\'';
                }

                const payload = {
                    listId: REGISTRY_REQUEST_FOR_RESEARCHER,
                    options: {
                        filter: filter
                    }
                }

                return this.$store.dispatch('getList', payload)
                    .then((res) => this.researchesList = res.results)
                    .catch(error => console.log(error))
                    .finally(() => this.$store.state.isLoading = false);

            },
            /**
             * Получение с сервера информации обо всех ответственных указанных во всех исследованиях
             * для заполнения полей "Ответственный"
             *
             * @return {void} Обновляет карту responsibleInfo
             */
            getResponsiblesInfo() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                // подготавливаем массив с ID
                let listForLoad = [];
                this.researchesList.forEach((item) => {
                    if (listForLoad.indexOf(+item.fldResponsibleId) === -1) {
                        listForLoad.push(+item.fldResponsibleId)
                    }
                });

                //Начинаем загрузку данных
                return Promise
                    .all(
                        listForLoad.map((id) => this.$store.dispatch('getUserInfoById', id)
                            .then((result) => {
                                this.responsibleInfo[id] = result;
                            })
                        )
                    )
                    .finally(() => this.$store.state.isLoading = false);
            },

        },
        mounted() {
            // получаем заявки
            this.getItemsForResearchesList()
            //получаем информацию по ответственным
                .then(() => this.getResponsiblesInfo());

        }
    }
</script>
