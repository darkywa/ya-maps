<template>
    <fieldset>
        <legend>
            Базовая информация о заявке
        </legend>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="form-group row">
                    <label for="BaseProject" class="col-sm-4 col-form-label text-left">Проект</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BaseProject" :value="fldProject"
                               readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseDirection" class="col-sm-4 col-form-label text-left">Дирекция<br><br></label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BaseDirection"
                               :value="fldDirection" readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseWorkPurpose" class="col-sm-4 col-form-label text-left">Цель работ</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BaseWorkPurpose"
                               :value="baseItem.fldWorkPurpose" readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseBasisOfOrder" class="col-sm-4 col-form-label text-left">Основание для заказа</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BaseBasisOfOrder"
                               :value="baseItem.fldOrderBasis" readonly placeholder="Не заполнено">
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="form-group row">
                    <label for="BasePriority" class="col-sm-4 col-form-label text-left">Приоритет</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BasePriority" :value="baseItem.fldPriority"
                               readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BasePerDirValue" class="col-sm-4 col-form-label text-left">Перспективное
                        направление</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BasePerDirValue"
                               :value="fldPerspectiveDirection" readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseTerm" class="col-sm-4 col-form-label text-left">Срок</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control" id="BaseTerm"
                               :value="baseItem.fldTerm" readonly placeholder="Не заполнено">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="BaseStatus" class="col-sm-4 col-form-label text-left">Статус</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="BaseStatus" :value="baseItem.fldStatus"
                               readonly placeholder="Не заполнено">
                    </div>
                </div>
            </div>
        </div>
    </fieldset>
</template>

<script>

    /** Импорт констант */
    import {REGISTRY_REQUEST_FOR_CUSTOMER} from '../../../constants/constants'

    export default {
        props: [
            /** хранилище для ID основной заявки, получаемой из справочника */
            'baseItemId',
        ],
        data() {
            return {
                /** хранилище для заявки, получаемой из справочника */
                baseItem: {},
                /** хранилище для параметра selec GET запроса, нужен что бы получать сразу Title на lookup полях */
                select: [
                    "fldProject/Title",
                    "fldDirection/fldDirection",
                    "fldPerspectiveDirection/Title",
                    "fldWorkPurpose",
                    "fldOrderBasis",
                    "fldPriority",
                    "fldTerm",
                    "fldStatus",
                ],
                /** хранилище для параметра expand GET запроса, нужен что бы получать сразу Title на lookup полях */
                expand: [
                    "fldProject",
                    "fldDirection",
                    "fldPerspectiveDirection",
                ]
            }
        },
        computed: {
            fldPerspectiveDirection() {
                return this.baseItem.fldPerspectiveDirection ? this.baseItem.fldPerspectiveDirection.Title : null;
            },
            fldProject() {
                return this.baseItem.fldProject ? this.baseItem.fldProject.Title : null;
            },
            fldDirection() {
                return this.baseItem.fldDirection ? this.baseItem.fldDirection.fldDirection : null;
            },

        },
        methods: {
            /**
             * Получение элемента из справочника "Реестр заявок» для заявителя и регистратора"
             * для заполнения полей "Базовая информация о заявке"
             *
             * @return {void} Обновляет свойство baseItem
             */
            getItemForBaseList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                const payload = {
                    listId: REGISTRY_REQUEST_FOR_CUSTOMER,
                    id: this.baseItemId,
                    options: {
                        select: this.select.toString(),
                        expand: this.expand.toString(),
                    },
                }

                this.$store.dispatch('getItem', payload)
                    .then((res) => this.baseItem = res)
                    .catch(error => console.error(error))
                    .finally(() => this.$store.state.isLoading = false);

            }
        },
        mounted() {
            // получаем заявку
            this.getItemForBaseList()
        }
    }
</script>
