<template>
    <fieldset>
        <legend>
            Заявки на испытания
        </legend>
        <div class="row">
            <div class="col-sm-12" v-if="testsList.length !== 0">
                <div class="samples-item" v-for="item in testsList" :key="item.ID">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="samples-modal-item">
                                <div class="form-group row">
                                    <label for="ResearchDirection"
                                           class="col-sm-4 col-form-label text-left">Тип испытания</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchDirection"
                                               :value="item.fldTestType"
                                               readonly placeholder="Не заполнено">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchComment"
                                           class="col-sm-4 col-form-label text-left">Комментарий</label>
                                    <div class="col-sm-8">
                                        <textarea type="text" class="form-control" id="ResearchComment"
                                                  :value="item.fldComment"
                                                  readonly placeholder="Не заполнено" rows="4"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchMethodic"
                                           class="col-sm-4 col-form-label text-left">Методика</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchMethodic"
                                               :value="item.fldMethodic"
                                               placeholder="Не заполнено">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ResearchMethodicName" class="col-sm-4 col-form-label text-left">Наименование
                                        методики</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ResearchMethodicName"
                                               :value="item.fldMethodicName"
                                               placeholder="Не заполнено">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group row">
                                <label for="ResearchAnalysisType" class="col-sm-4 col-form-label text-left">Метод
                                    испытания</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchAnalysisType"
                                           :value="item.fldTestMethod"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchStatus" class="col-sm-4 col-form-label text-left">Статус</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchStatus"
                                           :value="item.fldStatus"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchPrice"
                                       class="col-sm-4 col-form-label text-left">Стоимость</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchPrice"
                                           :value="item.fldPrice"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchDevice" class="col-sm-4 col-form-label text-left">Прибор</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchDevice"
                                           v-model="item.fldDevice"
                                           placeholder="Не заполнено">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ResearchResponsible"
                                       class="col-sm-4 col-form-label text-left">Ответственный</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ResearchResponsible"
                                           :value="responsibleInfo[item.fldResponsibleId]"
                                           placeholder="Не заполнено">
                                    <vue-bootstrap-typehead v-model="query"
                                                            placeholder="Не заполнено"
                                                            @hit="console.log($event)"
                                                            :data="queryResult"/>
                                    {{selectedValue}}
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- экшены формы -->
                    <RegistrarFormActions/>
                    <RegistrarFormResults/>
                </div>
            </div>
            <div v-else class="alert alert-info col-md-12" role="alert">
                Испытания не найдены <br> Проверьте являетесь ли вы ответственным по данной заявке или регистратором по
                данному направлению
            </div>
        </div>
    </fieldset>
</template>

<script>

    /** Импорт экшенов формы */
    import RegistrarFormActions from './RegistrarFormActions'
    /** Импорт испытателей */
    import RegistrarFormResults from './RegistrarFormResults.vue'
    /** Импорт констант */
    import {REGISTRY_REQUEST_FOR_TESTER} from '../../../constants/constants'

    /** Импорт lodash для debounce */
    import _ from 'lodash'

    export default {
        props: [
            /** хранилище для ID основной заявки, получаемой из справочника */
            'baseItemId',
        ],
        components: {
            RegistrarFormActions,
            RegistrarFormResults,
        },
        data() {
            return {
                /** список дирекций, получаемый из справочника */
                testsList: [],
                /** карта ответственных: id: info */
                responsibleInfo: {},

                /** bind value autocomlete */
                query: '',
                selectedValue: 's',
                /** bind value autocomlete */
                queryResult: ['Чучунов Михаил ', 'Савиных Виталий '],
            }
        },
        watch: {
            query(newQuestion, oldQuestion) {
                this.queryResult = ['Поиск пользователей'],
                    this.debouncedGetQuery()
            }
        },
        methods: {
            /**
             * Получение элементов из справочника «Реестр заявок» для исполнителя заявок на испытания
             * для вывода на страницу
             *
             * @return {void} Обновляет список testsList
             */
            getItemsForTestsList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                const payload = {
                    listId: REGISTRY_REQUEST_FOR_TESTER,
                    options: {
                        filter: 'fldMainRequestID/Id eq \'' + this.baseItemId + '\''
                    }
                }

                return this.$store.dispatch('getList', payload)
                    .then((res) => this.testsList = res.results)
                    .catch(error => console.error(error))
                    .finally(() => this.$store.state.isLoading = false);

            },
            /**
             * Получение с сервера информации обо всех ответственных указанных во всех исследованиях
             * для заполнения полей "Ответственный"
             *
             * @return {void} Обновляет карту responsibleInfo
             */
            getResponsiblesInfo() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                // подготавливаем массив с ID
                let listForLoad = [];
                this.testsList.forEach((item) => {
                    if (listForLoad.indexOf(+item.fldResponsibleId) === -1) {
                        listForLoad.push(+item.fldResponsibleId)
                    }
                });

                //Начинаем загрузку данных
                return Promise
                    .all(
                        listForLoad.map((id) => this.$store.dispatch('getUserInfoById', id)
                            .then((result) => {
                                this.responsibleInfo[id] = result;
                            })
                        )
                    )
                    .finally(() => this.$store.state.isLoading = false);
            },
            /**
             * Получение с сервера списка пользователей отвечающих запросу query
             * для вывода в Autocomplete
             *
             * @return {void} Обновляет список queryResult
             */
            getQuery() {
                const request =
                    '<Request xmlns="http://schemas.microsoft.com/sharepoint/clientquery/2009"' +
                    ' SchemaVersion="15.0.0.0" LibraryVersion="15.0.0.0" ApplicationName="Javascript Library">' +
                    '<Actions>' +
                    '<StaticMethod TypeId="{de2db963-8bab-4fb4-8a58-611aebc5254b}" Name="ClientPeoplePickerSearchUser" Id="1">' +
                    '<Parameters>' +
                    '<Parameter TypeId="{ac9358c6-e9b1-4514-bf6e-106acbfb19ce}">' +
                    '<Property Name="AllowEmailAddresses" Type="Boolean">false</Property>' +
                    '<Property Name="AllowMultipleEntities" Type="Boolean">true</Property>' +
                    '<Property Name="AllUrlZones" Type="Boolean">false</Property>' +
                    '<Property Name="EnabledClaimProviders" Type="String"></Property>' +
                    '<Property Name="ForceClaims" Type="Boolean">false</Property>' +
                    '<Property Name="MaximumEntitySuggestions" Type="Number">30</Property>' +
                    '<Property Name="PrincipalSource" Type="Number">15</Property>' +
                    '<Property Name="PrincipalType" Type="Number">1</Property>' +
                    '<Property Name="QueryString" Type="String">' +
                    this.query +
                    '</Property>' +
                    '</Parameter>' +
                    '</Parameters>' +
                    '</StaticMethod>' +
                    '</Actions>' +
                    '<ObjectPaths />' +
                    '</Request>';
                this.$store.dispatch('getUserByTitle', request)
                    .then((res) => {this.queryResult = JSON.parse(res[2])})
                    .catch(error => console.error(error))
            },
        },
        mounted() {
            // получаем заявку
            this.getItemsForTestsList()
            //получаем информацию по ответственным
                .then(() => this.getResponsiblesInfo());
        },
        created() {
            /**
             * _.debounce — это функция lodash, позволяющая ограничить то,
             * насколько часто может выполняться определённая операция.
             */
            this.debouncedGetQuery = _.debounce(this.getQuery, 500)
        },


    }
</script>
