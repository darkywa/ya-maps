<template>
    <fieldset>
        <legend>
            Результаты
        </legend>
        <div class="row">
            <div class="col-sm-12">
                <div class="samples-item">
                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <label for="ResultsName"
                                   class="col-md-12 col-form-label text-left">Наименование образца</label>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <label for="ResultsResult" class="col-md-12 col-form-label text-left">Результат</label>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <label for="ResultsUnitMeas"
                                   class="col-md-12 col-form-label text-left">Ед. измерения</label>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <label for="ResultsComment"
                                   class="col-md-12 col-form-label text-left">Комментарий</label>
                        </div>
                    </div>
                    <div class="row" v-for="item in 2" :key="item">
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="ResultsName"
                                           readonly placeholder="Не заполнено">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="ResultsResult"
                                           placeholder="Не заполнено">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="ResultsUnitMeas"
                                           placeholder="Не заполнено">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <textarea type="text" class="form-control" id="ResultsComment"
                                              placeholder="Не заполнено"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="offset-md-10 col-sm-2 text-center d-flex align-items-center justify-content-center">
                            <button type="button" @click="showResultModal" class="btn mr-2 form-group">
                                Добавить
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- модалка -->
        <b-modal ref="ResultModalRef" centered hide-footer title="Добавление образца">
            <div class="d-block text-center">
                <div class="form-group row">
                    <label for="newResultName" class="col-sm-6 col-form-label text-left">Наименование образца</label>
                    <div class="col-sm-6">
                        <input v-model="newResultDate" type="text" class="form-control" id="newResultName">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="newResultResult" class="col-sm-6 col-form-label text-left">Результат</label>
                    <div class="col-sm-6">
                        <input v-model="newResultDate" type="text" class="form-control" id="newResultResult">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="newResultUnitMeas" class="col-sm-6 col-form-label text-left">Ед. измерения</label>
                    <div class="col-sm-6">
                        <input v-model="newResultDate" type="text" class="form-control" id="newResultUnitMeas">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="newResultComment" class="col-sm-6 col-form-label text-left">Комментарий</label>
                    <div class="col-sm-6">
                        <textarea v-model="newResultDescription" rows="5" type="text" class="form-control"
                                  id="newResultComment"></textarea>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-right">
                <button type="button" @click="actionThisResult" class="btn btn-success mr-2">
                    <v-icon name="save"/>
                    Сохранить
                </button>
                <button type="button" @click="hideResultModal" class="btn btn-danger">
                    <v-icon name="ban"/>
                    Отмена
                </button>
            </div>
        </b-modal>
    </fieldset>
</template>

<script>

    /** Импорт констант */
    import {REGISTRY_REQUEST_FOR_TESTER} from '../../../constants/constants'

    export default {
        props: [
            /** хранилище для ID основной заявки, получаемой из справочника */
            'baseItemId',
        ],
        data() {
            return {
                /** список дирекций, получаемый из справочника */
                testsList: null,
            }
        },
        methods: {
            /**
             * Получение элементов из справочника «Реестр заявок» для исполнителя заявок на испытания
             * для вывода на страницу
             *
             * @return {void} Обновляет список testsList
             */
            getItemsForTestsList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                const payload = {
                    listId: REGISTRY_REQUEST_FOR_TESTER,
                    options: {
                        filter: 'fldMainRequestID/Id eq \'' + this.baseItemId + '\''
                    }
                }

                this.$store.dispatch('getList', payload)
                    .then((res) => this.testsList = res.results)
                    .catch(error => console.error(error))
                    .finally(() => this.$store.state.isLoading = false);

            },
            /**
             * Показывает окно добавления результата
             */
            showResultModal() {
                this.$refs.ResultModalRef.show()
            },
            /**
             * Скрывает окно добавления результата
             */
            hideResultModal() {
                this.$refs.ResultModalRef.hide()
            },

            /**
             * Сохранение кнопка в модальном окне
             */
            actionThisResult() {

            }
        },
        mounted() {
            // получаем заявку
            this.getItemsForTestsList()
        }


    }
</script>
