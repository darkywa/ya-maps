<template>
    <div class="container">
        <div class="row">
            <h2 class="col-sm-12 text-center">Общая форма Заявителя - создание заявки</h2>
        </div>
        <form class="main-form">

            <!-- базовые данные -->
            <CustomerFormBase/>

            <!-- добавление образцов -->
            <CustomerFormSamples/>

            <!-- добавление исследований -->
            <CustomerFormResearches/>

            <!-- добавление испытаний -->
            <CustomerFormTests/>

            <!-- экшены формы -->
            <CustomerFormActions/>

        </form>
    </div>
</template>

<script>

/** Импорт основной формы */
import CustomerFormBase from '../components/a/CustomerForm/CustomerFormBase.vue'
/** Импорт образцов */
import CustomerFormSamples from '../components/a/CustomerForm/CustomerFormSamples.vue'
/** Импорт исследований */
import CustomerFormResearches from '../components/a/CustomerForm/CustomerFormResearches.vue'
/** Импорт испытателей */
import CustomerFormTests from '../components/a/CustomerForm/CustomerFormTests.vue'
/** Импорт экшенов формы */
import CustomerFormActions from '../components/a/CustomerForm/CustomerFormActions.vue'

export default {
    components: {
        CustomerFormBase,
        CustomerFormSamples,
        CustomerFormResearches,
        CustomerFormTests,
        CustomerFormActions,
    },
    data() {
        return {
            
        }
    },
    methods: {
        
    },
    mounted() {
        // console.log('Общее состояние: ' + this.$store.state.count)
        // console.log('Артем состояние: ' + this.$store.state.a.count)
        // console.log('Миша состояние: ' + this.$store.state.m.count)
    }
}
</script>


<style lang="less">

</style>