<template>
    <div>
        Здесь, возможно, что-то будет :О
    </div>
</template>

<script>

export default {
    name: 'home'
}

</script>
