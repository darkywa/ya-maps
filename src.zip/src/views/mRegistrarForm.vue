<template>
    <div class="container">
        <form class="main-form">
            <!-- базовые данные -->
            <RegistrarFormBase :baseItemId="baseItemId"/>
            <!-- добавление образцов -->
            <RegistrarFormSamples :baseItemId="baseItemId"/>
            <!-- добавление исследований -->
            <RegistrarFormResearches v-if="fromResearchersPage"
                                     :baseItemId="baseItemId"
                                     :currentUserId="currentUserId"
                                     :directionListId="directionListId"/>
            <!-- добавление испытаний -->
            <RegistrarFormTests v-if="fromTestsPage"
                                :baseItemId="baseItemId"
                                :currentUserId="currentUserId"/>
        </form>
    </div>
</template>

<script>

    /** Импорт основной формы */
    import RegistrarFormBase from '../components/m/RegistrarForm/RegistrarFormBase.vue'
    /** Импорт образцов */
    import RegistrarFormSamples from '../components/m/RegistrarForm/RegistrarFormSamples.vue'
    /** Импорт исследований */
    import RegistrarFormResearches from '../components/m/RegistrarForm/RegistrarFormResearches.vue'
    /** Импорт испытателей */
    import RegistrarFormTests from '../components/m/RegistrarForm/RegistrarFormTests.vue'
    /** Импорт констант */
    import {HANDBOOK_DIRECTION_REGISTRARS} from '../constants/constants'

    export default {
        components: {
            RegistrarFormBase,
            RegistrarFormSamples,
            RegistrarFormResearches,
            RegistrarFormTests,
        },
        data() {
            return {
                /** хранилище для ID основной заявки, получаем из url */
                baseItemId: 0,
                /** хранилище для ID текущего пользователя, получаем с сервера */
                currentUserId: 0,
                /** пользователь перешел со страницы исследования, изменяем после разбора url */
                fromResearchersPage: false,
                /** пользователь перешел со страницы испытаний, изменяем после разбора url */
                fromTestsPage: false,
                /** хранилище для ID направлений доступных текущему пользователю, получаем из справочника */
                directionListId: [],
            }
        },
        methods: {
            /**
             * разбираем пришедшие get параметры url,
             * в зависимости от переданого параметра forPage изменяем fromTestsPage, fromResearchersPage
             *
             * @return {void} Обновляет свойство fromResearchersPage, fromTestsPage
             */
            checkReferer() {
                let query = this.$route.query;

                switch (query.forPage) {
                    case 'Researchers':
                        this.fromResearchersPage = true;
                        break;
                    case 'Tests':
                        this.fromTestsPage = true;
                        break;
                    default :
                        console.error('Переданный GET парамерт forPage не найден или не подходит - forPage:' + query.forPage);
                }
            },
            /**
             * разбираем пришедшие get параметры url,
             * записываем get baseItemId в baseItemId
             *
             * @return {void} Обновляет свойство baseItemId
             */
            getBaseItemId() {
                let query = this.$route.query;
                if (query.baseItemId) {
                    this.baseItemId = +query.baseItemId;
                } else {
                    console.error('Переданный GET парамерт baseItemId не найден - baseItemId:' + query.baseItemId);
                }
            },
            /**
             * Получение элементов из справочника "Справочник Доступы «Направления и регистраторы»"
             * для передачи в компонент RegistrarFormResearches
             *
             * @return {void} Обновляет список directionListId
             */
            getItemsForDirectionAndRegistrarsList() {
                // подрубаем лоадер
                this.$store.state.isLoading = true

                const payload = {
                    listId: HANDBOOK_DIRECTION_REGISTRARS,
                    options: {
                        filter: 'fldRegistrars/Id eq \'' + this.currentUserId + '\''
                    }
                }
                return this.$store.dispatch('getList', payload)
                    .then((res) => res.results.forEach(item => this.directionListId.push(item.fldDirectionsId)))
                    .catch(error => console.error(error))
                    .finally(() => this.$store.state.isLoading = false);

            },
            /**
             * Получение ID текущего пользователя
             *
             * @return {Promise} Обновляет свойство currentUserId
             */
            getCurrentUserId() {
                return this.$store.dispatch('getCurrentUser')
                    .then((res) => this.currentUserId = res.Id);
            }
        },
        created() {
            //Получаем ID базового элемента
            this.getBaseItemId()
            //Получение ID текущего пользователя
            this.getCurrentUserId()
            //Получаем ID направлений доступных текущему пользователю
                .then(() => this.getItemsForDirectionAndRegistrarsList())
                //определяем страницу откуда пришел пользователь
                .then(() => this.checkReferer());


        }
    }
</script>


<style lang="less">

</style>
