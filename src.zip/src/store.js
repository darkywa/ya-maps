// https://vuex.vuejs.org/ru/guide/modules.html

import Vue from 'vue'
import Vuex from 'vuex'
import {aStore} from './store/a-store'
import {mStore} from './store/m-store'
import {SERVER_URL} from './constants/constants'

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        // Артем
        a: aStore,
        // Миша
        m: mStore
    },    
    state: {
        // обычный лоадер
        isLoading: false,
        // лоадер с параметрами
        // статус
        paramLoaderStatus: false,
        // лог
        paramLoaderMessage: '',
        options: {
            headers: {
                'Content-Type': 'application/json; odata=verbose',
                'Accept': 'application/json; odata=verbose'
            }
        },
        baseUrl: SERVER_URL,
        apiUrl: SERVER_URL + '_api/web/lists/GetById(\'{0}\')/items',
    },
    mutations: {
        updateRefreshDigest(state, payload) {
            state.options.headers['X-RequestDigest'] = payload;
        },
        /** 
         * Лоадер с параметрами. Если вызывать мутацию без параметров,
         * то окно закроется, текст установиться дефолтный
         * Пример: this.$store.commit('loading', { s: true, m: 'Загружаем методы...' })
         * Закрываем: this.$store.commit('loading', {})
         * 
         * @param {Object} param объект с параметрами
         */
        loading(state, param) {
            state.paramLoaderStatus = param.s || false
            state.paramLoaderMessage = param.m || 'Загрузка. Пожалуйста, подождите...'
        },
    },
    actions: {
        /**
         *
         * Загружает с сервера X-RequestDigest,
         * Мутирует options.headers.X-RequestDigest
         * возвращает заголовки HTTP запроса
         *
         * @returns {Promise}
         */
        getRefreshDigest({commit, state}) {
            const url = state.baseUrl + '_api/contextinfo';
            return axios
                .post(url, null, state.options)
                .then((res) => {
                    commit('updateRefreshDigest', res.data.d.GetContextWebInformation.FormDigestValue);
                    return state.options;
                });
        },
        /**
         *
         * Загружает с сервера параметры текущего пользователя
         *
         * @returns {Promise}
         */
        getCurrentUser({state}) {
            const url = state.baseUrl + '_api/web/currentuser?$expand=Groups';
            return axios
                .get(url, state.options)
                .then((res) => {
                    return res.data.d;
                });
        },
        /**
         *
         * Загружает с сервера параметры пользователя
         *
         * @param {number} id - ID пользователя
         *
         * @returns {Promise}
         */
        getUserInfoById({state}, id) {
            const url = state.baseUrl + '_api/web/getUserById(' + id + ')';
            return axios
                .get(url, state.options)
                .then((res) => {
                    return res.data.d;
                });
        },
        /**
         *
         * Загружает с сервера параметры пользователя
         *
         * @param {number} name - XML запрос с именем пользователя в центре
         *
         * @returns {Promise}
         */
        getUserByTitle({dispatch, state}, name) {

            const url = state.baseUrl + '_vti_bin/client.svc/ProcessQuery';

            return dispatch('getRefreshDigest').then(() => {
                const localOptions = {...state.options};
                localOptions.headers['Content-Type'] = 'text/xml';
                localOptions.headers['X-Requested-With'] = 'XMLHttpRequest';
                return axios
                    .post(url, name, localOptions)
                    .then((res) => res.data);
            });
        },
        /**
         *
         * Загружает с сервера параметры пользователя
         *
         * @param {string} login - Логин пользователя ('i:0#.w|sibur\\savinykhve')
         *
         * @returns {Promise}
         */
        ensureUser({dispatch, state}, login) {
            const url = state.baseUrl + '_api/web/ensureuser';
            const payload = {logonName: login};
            const data = JSON.stringify(payload);
            return dispatch('getRefreshDigest').then(() => {
                const localOptions = {...state.options};
                localOptions.headers['X-Requested-With'] = 'XMLHttpRequest';
                return axios
                    .post(url, data, localOptions)
                    .then((res) => {
                        return res.data.d;
                    });
            });
        },
        /**
         *
         * Создает элемент списка
         * Возвращает созданный элемент
         *
         * @param {string} payload.listId - ID списка
         * @param {Object} payload.jsonBody - JSON
         *
         * @returns {Promise}
         */
        createItem({dispatch, state}, payload) {
            const url = state.apiUrl.replace('{0}', payload.listId);
            // append metadata
            if (!payload.jsonBody.__metadata) {
                payload.jsonBody.__metadata = {
                    type: 'SP.ListItem'
                };
            }
            const data = JSON.stringify(payload.jsonBody);
            return dispatch('getRefreshDigest').then(() => {
                return axios
                    .post(url, data, state.options)
                    .then((res) => {
                        return res.data.d;
                    });
            });
        },
        /**
         *
         * Удаление элемента списка
         *
         * @param {string} payload.listId - ID списка
         * @param {number} payload.id - id элемента
         *
         * @returns {Promise}
         */
        deleteItem({dispatch, state}, payload) {
            // append HTTP header DELETE for DELETE scenario
            const localOptions = {...state.options};
            localOptions.headers['X-HTTP-Method'] = 'DELETE';
            localOptions.headers['If-Match'] = '*';
            const url = state.apiUrl.replace('{0}', payload.listId) + '(' + payload.id + ')';
            return dispatch('getRefreshDigest').then(() => {
                return axios
                    .post(url, '', localOptions)
                    .then((resp) => {
                        return resp.data.d;
                    });
            });
        },
        /**
         *
         * Обновление элемента списка
         *
         * @param {string} payload.listId - ID списка
         * @param {number} payload.id - id элемента
         * @param {Object} payload.jsonBody - JSON
         *
         * @returns {Promise}
         */
        updateItem({dispatch, state}, payload) {
            // Append HTTP header MERGE for UPDATE scenario
            const localOptions = {...state.options};
            localOptions.headers['X-HTTP-Method'] = 'MERGE';
            localOptions.headers['If-Match'] = '*';
            // Append metadata
            if (!payload.jsonBody.__metadata) {
                payload.jsonBody.__metadata = {
                    type: 'SP.ListItem'
                };
            }
            const data = JSON.stringify(payload.jsonBody);
            const url = state.apiUrl.replace('{0}', payload.listId) + '(' + payload.id + ')';
            return dispatch('getRefreshDigest').then(() => {
                return axios
                    .post(url, data, localOptions)
                    .then((resp) => {
                        return resp.data.d;
                    });
            });
        },
        /**
         *
         * Получение списка с серверва
         *
         * @param {string} payload.listId - ID списка
         * @param {Object} payload.options - JSON
         *
         * @returns {Promise}
         */
        getList({state}, payload) {
            let url = state.apiUrl.replace('{0}', payload.listId);
            url = readBuilder(url, payload.options);
            return axios
                .get(url, state.options)
                .then((resp) => {
                    return resp.data.d;
                });
        },
        /**
         *
         * Получение элемента списка с серверва
         *
         * @param {string} payload.listId - ID списка
         * @param {number} payload.id - id элемента
         *
         * @returns {Promise}
         */
        getItem({state}, payload) {
            let url = state.apiUrl.replace('{0}', payload.listId) + '(' + payload.id + ')';
            url = readBuilder(url, payload.options);
            return axios
                .get(url, state.options)
                .then((resp) => {
                    return resp.data.d;
                });
        },
        /**
         *
         * Получение choice поля с выбором из списка с серверва
         *
         * @param {string} payload.listId - ID списка
         * @param {Object} payload.options - JSON
         *
         * @returns {Promise}
         */
        getChoices({state}, payload) {
            let url = state.apiUrl.replace('{0}', payload.listId);
            url = url.replace('items', 'fields');
            url = readBuilder(url, payload.options);
            return axios
                .get(url, state.options)
                .then((resp) => {
                    return resp.data.d;
                });
        }
    }
})

/**
 *
 * Дополнение параметрами url в зависимости от переданных options
 *
 * @param {string} url - url
 * @param {Object} options - JSON
 *
 * @returns {string}
 */
function readBuilder(url, options) {
    if (options) {
        if (options.filter) {
            url +=
                (url.endsWith('items') ? '?' : '&') +
                '$filter=' +
                options.filter;
        }
        if (options.select) {
            url +=
                (url.endsWith('items') || url.endsWith(')') ? '?' : '&') +
                '$select=' +
                options.select;
        }
        if (options.orderby) {
            url +=
                (url.endsWith('items') ? '?' : '&') +
                '$orderby=' +
                options.orderby;
        }
        if (options.expand) {
            url +=
                (url.endsWith('items') ? '?' : '&') +
                '$expand=' +
                options.expand;
        }
        if (options.top) {
            url +=
                (url.endsWith('items') ? '?' : '&') +
                '$top=' + options.top;
        }
        if (options.skip) {
            url +=
                (url.endsWith('items') ? '?' : '&') +
                '$skip=' + options.skip;
        }
        if (options.choices) {
            url +=
                (url.endsWith('fields') ? '?' : '&') +
                '$filter=' +
                options.choices;
        }
    }
    return url;
}