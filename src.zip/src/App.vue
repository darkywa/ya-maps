<template>
    <div id="app">
        <div id="nav">
            <router-link to="/">Главная</router-link> |
            <router-link to="/customer-form">Форма для заявителя</router-link> |
            <router-link to="/registrar-form?forPage=Researchers&baseItemId=105">Форма для регистратора</router-link>
        </div>
        <hr>
        <div class="app-wrap">
            <router-view/>
        </div>

        <!-- обычный лоадер -->
        <div v-show="$store.state.isLoading" class="loading">
            <div class="loading__overlay"></div>
            <div class="loading__wrap">
                <div class="loading__icon">
                    <div class="loading__loader" id="loader-1"></div>
                </div>
                <div class="loading__text">
                    Загрузка. Пожалуйста, подождите...
                </div>
            </div>
        </div>

        <!-- лоадер с параметрами -->
        <loader
            v-show="$store.state.paramLoaderStatus"
            :message="$store.state.paramLoaderMessage"
        />

  </div>
</template>

<script>

// импорт лоадера - next lvl
import loader from './components/loader.vue'

export default {
    components: {
        loader
    },
    data() {
        return {

        }
    },
    methods: {
        
    },
    mounted() {
        // console.log('Общее состояние: ' + this.$store.state.count)
        // console.log('Артем состояние: ' + this.$store.state.a.count)
        // console.log('Миша состояние: ' + this.$store.state.m.count)
    }
}
</script>


<style lang="less">

@import './less/loader.less';

#app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;

    .app-wrap {
        padding: 50px 0;
    }

    .main-form {
        padding: 1.5rem;
        border-width: .2rem;
        position: relative;
        margin: 1rem -15px 0;
        border: solid #f8f9fa;

        fieldset {
            padding: 20px;
            background-color: #fafafa;
            margin-bottom: 40px;

            &:last-child {
                margin-bottom: 0;
            }
        }

        legend {
            margin-top: 20px;
        }

        .samples-item {
            background-color: #fff;
            padding: 20px 20px 0;
            margin-bottom: 20px;
            border: 1px solid #ddd;

            &:last-child {
                margin-bottom: 0;
            }
        }

        .sample-property {
            font-weight: bold;
            width: 50%;
        }
    }
}
#nav {
    padding: 30px;
    a {
        font-weight: bold;
        color: #2c3e50;
        &.router-link-exact-active {
            color: #42b983;
        }
    }
}

</style>
