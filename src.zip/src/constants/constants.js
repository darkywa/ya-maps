// общий сервер
export const SERVER_URL = 'http://s001nd-sp-dev3/ilc/';

// Справочник «Проекты»
export const HANDBOOK_PROJECT = 'A74352D1-EA4E-4D0D-81AC-7D38BDE7685C';

// Справочник «Перспективные направления»
export const HANDBOOK_PERSPECTIVE_DIRECTIONS = 'D69107CC-05DB-4E2E-9B27-97C4CD9AC11D';

// «Реестр заявок» для заявителя и регистратора
export const REGISTRY_REQUEST_FOR_CUSTOMER = 'F13CAB2A-5FEF-42FC-9409-B72968EB0C63';

// «Реестр заявок» для исполнителя заявок на испытания
export const REGISTRY_REQUEST_FOR_TESTER = '44AAF776-0D4B-44BB-81C2-24430F246522';

// «Реестр заявок» для исполнителя заявок на исследования
export const REGISTRY_REQUEST_FOR_RESEARCHER = '64CAFDFE-2D20-40B4-9C6D-E67351CECD7A';

// «Реестр образцов» для общих заявок
export const REGISTRY_SAMPLES = '7FEDB8C5-D7AF-4C37-8B31-0DC3AB386700';

// Результаты образцов
export const SAMPLES_RESULTS = 'C2A65AEB-1E03-4CFF-A016-3F79B15CDE42';

// Справочник «Методики»
export const HANDBOOK_METHODICS = '4B4BC158-4A08-48DF-9CA6-F5927E5A19AF';

// Справочник «Прайс ИЛЦ»
export const HANDBOOK_PRICE = '70C5F2E5-01E8-4547-B42D-F38145AA34FB';

// Справочник «Статус работоспособности оборудования»
export const HANDBOOK_EQUIP_STATUS = '9802B28A-631E-4F9D-8FC4-EB56DB417059';

// Справочник «Типы испытаний»
export const HANDBOOK_TESTS_TYPES = 'ACF4CA49-2D10-4B1C-8370-34B24666CC2F';

// Справочник «Типы исследований»
export const HANDBOOK_RESEARCHS_TYPES = '15F3F34C-B289-45BE-BBC3-E15AAB5166C1';

// Справочник Типы исследований: Метод
export const HANDBOOK_RESEARCHES_METHOD = 'DA390F7F-3B2F-4042-A91F-A5CD8FB0F415';

// Справочник Типы исследований: Тип анализа
export const HANDBOOK_RESEARCHES_ANALYSIS = '7393E46A-DC0D-4882-ACBC-24355260BE20';

// Справочник Типы исследований: Задача
export const HANDBOOK_RESEARCHES_TASK = '870EE7DD-A36C-4F71-965D-BDCF606BC44A';

// Справочник Типы испытаний: Метод
export const HANDBOOK_TESTERS_METHOD = '9F298A6B-33C2-4E90-8E86-19F30A8BDD28';

// Справочник «Наименование методики»
export const HANDBOOK_METHODICS_NAME = '7449E727-CBEC-4A8F-B1E2-BA4E54429FFD';

// Справочник «Наименование условий»
export const HANDBOOK_CONDITIONS_NAME = '97F25F90-955E-484D-9891-6AB5C7F50235';

// Справочник «Значения условий»
export const HANDBOOK_CONDITIONS_VALUE = 'BCC6F7F5-B493-4DB1-A92D-B43343135913';

// Справочник «Единицы измерения»
export const HANDBOOK_METHODICS_UNIT_MEAS = '9A4C297F-BAB8-4A18-AAF0-3DE8FE7ED553';

// Доступы - Исследования
export const HANDBOOK_DIRECTION_REGISTRARS = 'C23C88F8-DE80-42F2-8FDD-5026E2CE5A19';

// Доступы - Испытания
export const HANDBOOK_ACCESS_UNIT_MEAS = '26E2DF23-EFEF-4244-A84F-D29EFA125A1D';