export const mStore = {
    state: {
    },
    mutations: {

    },
    actions: {

    }
};