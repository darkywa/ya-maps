import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
// форма заявителя
import CustomerForm from './views/aCustomerForm.vue'
// форма регистратора
import RegistrarForm from './views/mRegistrarForm'

Vue.use(Router)

export default new Router({
  routes: [
    {
        path: '/',
        name: 'home',
        component: Home
    },
    /**
     * Форма заявителя
     * @author KirilenkoAS <kirilenkoas@nipigas.ru>
     */
    {
        path: '/customer-form',
        name: 'CustomerForm',
        component: CustomerForm
    },
      {
          path: '/registrar-form',
          name: 'RegistrarForm',
          component: RegistrarForm
      }
  ]
})
