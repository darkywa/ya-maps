// общий сервер
export const serverURL = 'http://s001nd-sp-dev3/ilc/';
// Проекты
export const handBookProject = 'A74352D1-EA4E-4D0D-81AC-7D38BDE7685C';
// «Перспективные направления»
export const handBookPerspectiveDirection = 'D69107CC-05DB-4E2E-9B27-97C4CD9AC11D';